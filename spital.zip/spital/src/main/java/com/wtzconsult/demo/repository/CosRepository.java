package com.wtzconsult.demo.repository;

import com.wtzconsult.demo.bo.Cos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CosRepository extends JpaRepository <Cos,Long> {
}
