package com.wtzconsult.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpitalApplication.class, args);
	}

}
